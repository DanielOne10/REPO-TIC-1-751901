let data = { "users": [], "tasks": [], "tags": [] };

//Para mostrar en table
const asTable = (arr) => arr.map(x => x.toObject ? x.toObject() : x);

//Función principal de pruebas
function runAllTests() {
    //PUNTO 1
    console.log("<-- PUNTO 1: Arreglos vacíos -->");
    console.log("Users:");  console.table(asTable(getAllUsers()));
    console.log("Tasks:");  console.table(asTable(getAllTasks()));
    console.log("Tags:");   console.table(asTable(getAllTags()));

    //PUNTO 2
    console.log("<-- PUNTO 2: Crear 3 usuarios -->");
    createUser("User 1", "u1@correo.com", "Passw0rd#");
    createUser("User 2", "u2@correo.com", "Passw0rd#");
    createUser("User 3", "u3@correo.com", "Passw0rd#");
    console.table(asTable(getAllUsers()));
    
    //PUNTO 3
    console.log("<-- PUNTO 3: Usuario con ID = 2 -->");
    console.log(getUserById(2));
    console.table(getUserById(2));

    //PUNTO 4
    console.log("<-- PUNTO 4: Filtrar usuarios por nombre contiene 'User' -->");
    console.table(asTable(searchUsers('name','User')));
    
    //PUNTO 5
    console.log("<-- PUNTO 5: Modificar usuario ID 3 -->");
    console.log(updateUser(3, { name: "ACTUALIZADORX" }));
    console.table(asTable(getAllUsers()));
    //console.table(getAllUsers().map(u => u.toObject()));
    
    //PUNTO 6
    console.log("<-- PUNTO 6: Eliminar usuario ID 1 -->");
    deleteUser(1);
    console.table(asTable(getAllUsers()));

    //PUNTO 7
    console.log("<-- PUNTO 7: Crear 5 etiquetas -->");
    createTag("Trabajo", "#ff10aa");
    createTag("Escuela", "#00ccff");
    createTag("Personal", "#22aa22");
    createTag("Urgente", "#fcba03");
    createTag("Hogar", "#aaaaaa");
    console.table(asTable(getAllTags()));
      
    //PUNTO 8
    console.log("<-- PUNTO 8: Modificar etiqueta ID 4 -->");
    console.log(updateTag(4, { name: "ETIQUETADORX", color: "#fcba03" }));
    console.table(asTable(getAllTags()));

    //PUNTO 9
    console.log("<-- PUNTO 9: Eliminar etiqueta ID 2 -->");
    deleteTag(2);
    console.table(asTable(getAllTags()));

    //PUNTO 10
    console.log("<-- PUNTO 10: Crear 7 tareas (>=2 tags) -->");
    //Users existentes: 2 (ID=2) y 3 (ID=3)  (ID=1 fue borrado)
    createTask("Tarea 1","Desc 1","2025-10-01",2,'A',[1,3]);
    createTask("Tarea 2","Desc 2","2025-10-02",2,'A',[3,4]);
    createTask("Tarea 3","Desc 3","2025-10-03",3,'C',[1,5]);
    createTask("Tarea 4","Desc 4","2025-10-04",3,'F',[1,4]);
    createTask("Tarea 5","Desc 5","2025-10-05",2,'A',[1,5]);
    createTask("Tarea 6","Desc 6","2025-10-06",3,'A',[3,5]);
    createTask("Tarea 7","Desc 7","2025-10-07",2,'A',[1,3,5]);
    console.table(asTable(getAllTasks()));

    //PUNTO 11
    console.log("<-- PUNTO 11: Tarea ID 5 sin etiquetas -->");
    updateTask(5, { tags: [] });
    console.table(asTable(getAllTasks()));
            
    //PUNTO 12
    console.log("<-- PUNTO 12: Tareas ID 1 y 4 con descripción 'Dorx Task' -->");
    updateTask(1, { description: "Dorx Task" });
    updateTask(4, { description: "Dorx Task" });
    console.table(asTable(getAllTasks()));

    //PUNTO 13
    console.log("<-- PUNTO 13: Filtrar tareas con 'Dorx' en descripción -->");
    console.table(asTable(searchTasks('description','Dorx')));
              
    //PUNTO 14
    console.log("<-- PUNTO 14: Filtrar tareas por etiqueta(s) -->");
    console.log("Por etiqueta 1:");
    console.table(asTable(searchTasks('tags',1)));
    console.log("findTasksByTag([1,5]) (ANY):");
    console.table(asTable(findTasksByTag([1,5])));
              
    //PUNTO 15
    console.log("<-- PUNTO 15: Eliminar tarea ID 3 -->");
    deleteTask(3);
    console.table(asTable(getAllTasks()));

    //PUNTO 16 (el profe hará pruebas de excepciones) – aquí sólo ejemplo:
    console.log("<-- PUNTO 16: Ejemplos de excepciones (comentado para no detener ejecución) -->");
    //try { createUser("X","u2@correo.com","short"); } catch(e){ console.warn(e); }
    //try { deleteTag(1); } catch(e){ console.warn(e); } // si está usada en tareas
    //try { createTask("Bad","", "fecha-mala", 2, 'A', [1]); } catch(e){ console.warn(e); }
    
    console.log("<--PUNTO 17: Reporte (Se lo mandé por canvas en un link)-->");
    }
    
    //Opcional: ejecuta automáticamente al cargar
    runAllTests();