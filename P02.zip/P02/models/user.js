function getNextUserID(){
    const w = (typeof window !== 'undefined') ? window : globalThis;
      const store = (typeof data !== 'undefined') ? data : w.data;
      if (!store || !Array.isArray(store.users) || store.users.length === 0) return 1;
      const max = Math.max(...store.users.map(u => Number(u.id)));
      return max + 1;
}

class UserException {
    constructor(errorMessage) {
        this.errorMessage = errorMessage;
    }
}

class User {
    #id; 
    #name; 
    #email; 
    #password; 
    #joined_at;
    
    constructor(name, email, password) {
        this.#id = getNextUserID();
        this.name = name;
        this.email = email;
        this.password = password;
        this.#joined_at = new Date();
    
        
        
        }
        
          get id() {return this.#id;}
          set id(_) {throw new UserException("IDs are auto-generated.");}
        
          get name() {return this.#name;}
          set name(v) {
            if (!v || String(v).trim() === '') throw new UserException("Name cannot be empty");
            this.#name = String(v).trim();
          }

        get email() {return this.#email;}
        set email(v) {
          if (!v || String(v).trim() === '') throw new UserException("Email cannot be empty");
          const email = String(v).trim().toLowerCase();
        
          const w = (typeof window !== 'undefined') ? window : globalThis;
          const store = (typeof data !== 'undefined') ? data : w.data;
          if (store && Array.isArray(store.users)) {
            const duplicated = store.users.find(u =>
              u.email.toLowerCase() === email && Number(u.id) !== Number(this.#id)
            );
            if (duplicated) throw new UserException("Email already exists");
          }
        
          this.#email = email;
        }
        

        get password() {return this.#password;}
          set password(v) {
            if (!v) throw new UserException("Password cannot be empty");
            const s = String(v);
            if (s.length < 8) throw new UserException("Password must be at least 8 characters");
            this.#password = s;
          }
        
          get joined_at() {return this.#joined_at;}
          set joined_at(_) {throw new UserException("joined_at is auto-generated.");}

          toObject() {
              return {
                id: this.#id,
                name: this.#name,
                email: this.#email,
                password: this.#password,
                joined_at: this.#joined_at.toISOString()
              };
            }
}