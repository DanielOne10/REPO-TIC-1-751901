function __store__() {
  const w = (typeof window !== 'undefined') ? window : globalThis;
  return (typeof data !== 'undefined') ? data : w.data;
}

function getNextTaskID(){
  const store = __store__();
    if (!store || !Array.isArray(store.tasks) || store.tasks.length === 0) return 1;
    const max = Math.max(...store.tasks.map(t => Number(t.id)));
    return max + 1;
    /*const w = (typeof window !== 'undefined') ? window : globalThis;
      const store = (typeof data !== 'undefined') ? data : w.data;
      if (!store || !Array.isArray(store.tasks) || store.tasks.length === 0) return 1;
      const max = Math.max(...store.tasks.map(u => Number(u.id)));
      return max + 1;*/
}

class TaskException {
    constructor(errorMessage) {
        this.errorMessage = errorMessage;
    }
}

function parseDateOrThrow(v) {
  const d = (v instanceof Date) ? v : new Date(v);
  if (isNaN(d.getTime())) throw new TaskException("Invalid date");
  return d;
}

class Task {
    #id; 
    #title; 
    #description; 
    #due_date; 
    #owner; 
    #status; 
    #tags;
    
      constructor(title, description, due_date, owner, status = 'A', tags = []) {
        this.#id = getNextTaskID();
        this.title = title;
        this.description = description ?? '';
        this.due_date = due_date;
        this.owner = owner;
        this.status = status;
        this.tags = tags;

        
        }

        get id() { return this.#id; }
        set id(_) { throw new TaskException("IDs are auto-generated."); }
        
        get title() { return this.#title; }
        set title(v) {
            if (!v || String(v).trim() === '') throw new TaskException("Title cannot be empty");
            this.#title = String(v).trim();
        }

        get description() { return this.#description; }
        set description(v) {
            this.#description = String(v ?? '');
        }
        
        get due_date() { return this.#due_date; }
        set due_date(v) {
            this.#due_date = parseDateOrThrow(v);
        }

        get owner() { return this.#owner; }
        set owner(v) {
          const id = Number(v);
          const store = __store__();
        
          if (!store || !Array.isArray(store.users)) {
            throw new TaskException("Users data not available");
          }
          const exists = store.users.some(u => Number(u.id) === id);
          if (!exists) throw new TaskException("Owner must be an existing User ID");
        
          this.#owner = id;
        }
        /*set owner(v) {
            const id = Number(v);
            const w = (typeof window !== 'undefined') ? window : globalThis;
            if (!w.data || !Array.isArray(w.data.users)) throw new TaskException("Users data not available");
            const exists = w.data.users.some(u => u.id === id);
            if (!exists) throw new TaskException("Owner must be an existing User ID");
            this.#owner = id;
        }*/

        get status() { return this.#status; }
        set status(v) {
            const val = String(v ?? 'A').toUpperCase();
            if (!['A', 'F', 'C'].includes(val))
              throw new TaskException("Status must be one of A/F/C");
            this.#status = val;
        }

        get tags() { return this.#tags; }
        set tags(arr) {
          if (!Array.isArray(arr)) throw new TaskException("Tags must be an array of Tag IDs");
        
          const store = __store__();
          if (!store || !Array.isArray(store.tags)) {
            throw new TaskException("Tags data not available");
          }
        
          for (const tagId of arr) {
            if (!store.tags.some(t => Number(t.id) === Number(tagId))) {
              throw new TaskException(`Tag ${tagId} does not exist`);
            }
          }
          this.#tags = arr.map(Number);
        }
        /*set tags(arr) {
            if (!Array.isArray(arr)) throw new TaskException("Tags must be an array of Tag IDs");
            const w = (typeof window !== 'undefined') ? window : globalThis;
            if (!w.data || !Array.isArray(w.data.tags)) throw new TaskException("Tags data not available");
            for (const tagId of arr) {
              if (!w.data.tags.some(t => t.id === Number(tagId))) {
                throw new TaskException(`Tag ${tagId} does not exist`);
              }
            }
            this.#tags = arr.map(n => Number(n));
        }*/

        toObject() {
            return {
              id: this.#id,
              title: this.#title,
              description: this.#description,
              due_date: this.#due_date.toISOString(),
              owner: this.#owner,
              status: this.#status,
              tags: [...this.#tags]
            };
        }
}