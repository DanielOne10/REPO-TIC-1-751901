function getNextTagID(){
    const w = (typeof window !== 'undefined') ? window : globalThis;
      const store = (typeof data !== 'undefined') ? data : w.data;
      if (!store || !Array.isArray(store.tags) || store.tags.length === 0) return 1;
      const max = Math.max(...store.tags.map(u => Number(u.id)));
      return max + 1;
}

class TagException {
    constructor(errorMessage) {
        this.errorMessage = errorMessage;
    }
}

function isValidHexColor(str) {
  return /^#([0-9a-fA-F]{6})$/.test(String(str).trim());
}

class Tag {
    #id;
    #name;
    #color;
    constructor(name, color) {
        this.#id = getNextTagID();
        this.name = name;
        this.color = color;

        
        
    }

    get id() {
        return this.#id;
    }
    set id(_) {
        throw new TagException("IDs are auto-generated.");
    }

    get name() { 
        return this.#name; 
    }
      set name(v) {
        if (!v || String(v).trim() === '') throw new TagException("Name cannot be empty");
        this.#name = String(v).trim();
      }
    
      get color() { 
        return this.#color; 
    }
      set color(v) {
        if (!v || !isValidHexColor(v)) throw new TagException("Color is not valid");
        this.#color = String(v).trim();
      }

      toObject() {
          return { 
            id: this.#id, name: this.#name, color: this.#color 
            };
        }
}