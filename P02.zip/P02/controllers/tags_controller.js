function createTag(name, color) {
  const tag = new Tag(name, color);
  data.tags.push(tag);
}

function getTagById(id) {
  const uid = Number(id);
  const tag = data.tags.find(t => Number(t.id) === uid);
  return tag || "404 - Tag not found";
}

function searchTags(attribute, value) {
  const validAttrs = ['id', 'name', 'color'];
  if (!validAttrs.includes(attribute)) throw new TagException(`Unknown attribute: ${attribute}`);
  const query = String(value).toLowerCase();
  return data.tags.filter(t => String(t[attribute]).toLowerCase().includes(query));
}

function getAllTags() { return data.tags; }

function updateTag(id, obj_new_info = {}) {
  const tag = data.tags.find(t => t.id === Number(id));
  if (!tag) throw new TagException("Tag not found");

  const allowed = ['name','color'];
    let updated = false;
    for (const [k,v] of Object.entries(obj_new_info)) {
      if (!allowed.includes(k)) continue;
      tag[k] = v;
      updated = true;
    }
    if (!updated) throw new TagException("No valid attributes to update");
    return true;
  }

  function deleteTag(id) {
    const tid = Number(id);
    // Validar que no esté en ninguna task
    /*const usedIn = [];
    for (const task of data.tasks) {
      for (const tid of task.tags) {
        if (tid === tagId) { usedIn.push(task.id); break; }
      }
    }*/
   const usedIn = data.tasks
      .filter(t => Array.isArray(t.tags) && t.tags.some(tagId => Number(tagId) === tid))
      .map(t => t.id);


    if (usedIn.length > 0) {
      throw new TagException(`Cannot delete Tag. Used in Tasks: ${usedIn.join(',')}`);
    }
    const idx = data.tags.findIndex(t => Number(t.id) === tid);
      if (idx === -1) throw new TagException("Tag not found");
      data.tags.splice(idx, 1);
    }