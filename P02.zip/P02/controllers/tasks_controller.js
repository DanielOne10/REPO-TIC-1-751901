function createTask(title, description, due_date, owner, status = 'A', tags = []) {
  const task = new Task(title, description, due_date, owner, status, tags);
  data.tasks.push(task);
}

function getTaskById(id) {
  const uid = Number(id);
  const task = data.tasks.find(t => Number(t.id) === uid);
  return task || "404 - Task not found";
}

function searchTasks(attribute, value) {
  const validAttrs = ['id','title','description','due_date','owner','status','tags'];
    if (!validAttrs.includes(attribute)) {
      throw new TaskException(`Unknown attribute: ${attribute}`);
    }
  
    
    if (attribute === 'id') {
      const nid = Number(value);
      return data.tasks.filter(t => Number(t.id) === nid);
    }
  
    if (attribute === 'owner') {
      const oid = Number(value);
      return data.tasks.filter(t => Number(t.owner) === oid);
    }
  
    if (attribute === 'status') {
      const st = String(value).toUpperCase();
      return data.tasks.filter(t => String(t.status).toUpperCase() === st);
    }

    
    if (attribute === 'due_date') {
      const qd = (value instanceof Date) ? value : new Date(value);
      if (isNaN(qd)) throw new TaskException("Invalid date for search");
      const target = qd.toISOString().slice(0,10);
      return data.tasks.filter(t => t.due_date.toISOString().slice(0,10) === target);
    }
  
    
    if (attribute === 'tags') {
      
      if (Array.isArray(value)) {
        const set = new Set(value.map(Number));
        return data.tasks.filter(t => t.tags.some(tagId => set.has(Number(tagId))));
      }
      
      const tagId = Number(value);
      return data.tasks.filter(t => t.tags.includes(tagId));
    }
  
    
    const q = String(value).toLowerCase();
    return data.tasks.filter(t => String(t[attribute]).toLowerCase().includes(q));
  /*const validAttrs = ['id','title','description','due_date','owner','status','tags'];
  if (!validAttrs.includes(attribute)) throw new TaskException(`Unknown attribute: ${attribute}`);

  if (attribute === 'due_date') {
    const qd = new Date(value);
    if (isNaN(qd)) throw new TaskException("Invalid date for search");
    const target = qd.toISOString().slice(0,10); //Comparar por YYYY-MM-DD
    return data.tasks.filter(t => t.due_date.toISOString().startsWith(target));
  }

  if (attribute === 'tags') {
      
      const tagId = Number(value);
      return data.tasks.filter(t => t.tags.includes(tagId));
    }
  
    const query = String(value).toLowerCase();
    return data.tasks.filter(t => String(t[attribute]).toLowerCase().includes(query));*/
  }
  
  function getAllTasks() { return data.tasks; }

  function updateTask(id, obj_new_info = {}) {
    const task = data.tasks.find(t => t.id === Number(id));
    if (!task) throw new TaskException("Task not found");
  
    const allowed = ['title','description','due_date','owner','status','tags'];
    let updated = false;
    for (const [k,v] of Object.entries(obj_new_info)) {
      if (!allowed.includes(k)) continue;
      task[k] = v;
      updated = true;
    }
    if (!updated) throw new TaskException("No valid attributes to update");
    return true;
  }

  function deleteTask(id) {
    const tid = Number(id);
    const idx = data.tasks.findIndex(t => Number(t.id) === tid);
    if (idx === -1) throw new TaskException("Task not found");
    data.tasks.splice(idx, 1);
  }

  function findTasksByTag(arrayOfTagIds) {
    const set = new Set(arrayOfTagIds.map(n => Number(n)));
    return data.tasks.filter(t => t.tags.some(id => set.has(id)));
  }

  function findTasksByTagAll(tagIds) {
    const list = tagIds.map(Number);
    return data.tasks.filter(t => list.every(id => t.tags.includes(id)));
  }