function createUser(name, email, password) {
  const user = new User(name, email, password);
  data.users.push(user);
}

function getUserById(id) {
  const uid = Number(id);
  const user = data.users.find(u => Number(u.id) === uid);
  return user || "404 - User not found";
}

function searchUsers(attribute, value) {
  const validAttrs = ['id','name','email','password','joined_at'];
  if (!validAttrs.includes(attribute)) {
    throw new UserException(`Unknown attribute: ${attribute}`);
  }

  
  if (attribute === 'id') {
    const nid = Number(value);
    return data.users.filter(u => Number(u.id) === nid);
  }

  
  if (attribute === 'joined_at') {
    const qd = (value instanceof Date) ? value : new Date(value);
    if (isNaN(qd)) throw new UserException("Invalid date for search");
    const target = qd.toISOString().slice(0,10);
    return data.users.filter(u => u.joined_at.toISOString().slice(0,10) === target);
  }

  
  const query = String(value).toLowerCase();
  return data.users.filter(u => String(u[attribute]).toLowerCase().includes(query));
}
/*function searchUsers(attribute, value) {
  const validAttrs = ['id','name','email','password','joined_at'];
  if (!validAttrs.includes(attribute)) throw new UserException(`Unknown attribute: ${attribute}`);
  const query = String(value).toLowerCase();

  return data.users.filter(u => {
      let v;
      if (attribute === 'joined_at') v = u.joined_at.toISOString();
      else v = String(u[attribute]);
      return String(v).toLowerCase().includes(query);
    });
  }*/
  
  function getAllUsers() { return data.users; }
  
  function updateUser(id, obj_new_info = {}) {
    const uid = Number(id);
    const user = data.users.find(u => Number(u.id) === uid);
    if (!user) throw new UserException("User not found");
  
    const allowed = ['name','email','password'];
    let updated = false;
  
    
    if (Object.prototype.hasOwnProperty.call(obj_new_info, 'email')) {
      const newEmail = String(obj_new_info.email).trim().toLowerCase();
      const dup = data.users.find(u =>
        u.email.toLowerCase() === newEmail && Number(u.id) !== uid
      );
      if (dup) throw new UserException("Email already exists");
    }
      
    for (const [k, v] of Object.entries(obj_new_info)) {
      if (!allowed.includes(k)) continue;
      
          
      const current = String(user[k]);
      const next = String(v);
      if (current === next) continue;
      
      user[k] = v;
      updated = true;
    }
          
    if (!updated) throw new UserException("No valid attributes to update");
    return true;
  }
  /*function updateUser(id, obj_new_info = {}) {
    const user = data.users.find(u => u.id === Number(id));
    if (!user) throw new UserException("User not found");

    const allowed = ['name','email','password'];
      let updated = false;
    
      for (const [k, v] of Object.entries(obj_new_info)) {
        if (!allowed.includes(k)) continue;
        user[k] = v; //Setters con validaciones
        updated = true;
      }
      if (!updated) throw new UserException("No valid attributes to update");
      return true;
    }*/

    function deleteUser(id) {
      const uid = Number(id);
      //No se puede eliminar si tiene tareas
      const tasksAssigned = data.tasks.filter(t => Number(t.owner) === uid).map(t => t.id);
      if (tasksAssigned.length > 0) {
        throw new UserException(`Cannot delete User. Has Tasks: ${tasksAssigned.join(',')}`);
      }
      const idx = data.users.findIndex(u => Number(u.id) === uid);
      if (idx === -1) throw new UserException("User not found");
      data.users.splice(idx, 1);
    }